package scripts

ZDEKS = new double[LL]
for (i = 0; i < LL; i++) ZDEKS[i] = EKS[i] / PKB[i];